import PIRoundInterview from '@/components/PIRoundInterview';

export default function Home() {
  return (
    <main>
      <PIRoundInterview />
    </main>
  );
}