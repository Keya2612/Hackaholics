"use client";

import Header from "@/components/landing_page/Header";

export default function DashboardPage() {
  return (
    <>
      <Header />
      <div className="p-6">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-600 mt-2">
          Welcome to your dashboard. Monitor your progress and access all features
          from the sidebar.
        </p>
        {/* Add more dashboard content here as needed */}
      </div>
    </>
  );
}