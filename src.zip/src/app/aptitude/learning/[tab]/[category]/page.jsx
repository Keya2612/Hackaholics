"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { useState, useEffect } from "react";
import { progressData, tabs } from "../../../learning/data";
import { learningContent } from "../../../learning/learningContent";

const CategoryLearning = () => {
  const { tab, category } = useParams();

  // Find tab name for display
  const tabData = tabs.find((t) => t.id === tab);
  const tabName = tabData ? tabData.name : tab;

  // Get topics for the category
  const topics = progressData[tab]?.[category] || [];

  // Get learning content for the category
  const content = learningContent[tab]?.[category] || {};

  // State to track checkbox status
  const [completionStatus, setCompletionStatus] = useState(() => {
    // Load from localStorage or initialize empty
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem(`completion_${tab}_${category}`);
      return saved ? JSON.parse(saved) : {};
    }
    return {};
  });

  // Save to localStorage and update progress whenever completionStatus changes
  useEffect(() => {
    localStorage.setItem(
      `completion_${tab}_${category}`,
      JSON.stringify(completionStatus)
    );

    // Update progress in progressData
    topics.forEach((topic) => {
      const youtubeCompleted = completionStatus[`${topic.title}_youtube`] || false;
      const pdfCompleted = completionStatus[`${topic.title}_pdf`] || false;
      // Each resource contributes to progress (50% for each if both exist)
      const resourceCount =
        (content[topic.title]?.youtubeLink ? 1 : 0) +
        (content[topic.title]?.pdfLink ? 1 : 0);
      const completedCount = (youtubeCompleted ? 1 : 0) + (pdfCompleted ? 1 : 0);
      topic.progress = resourceCount > 0 ? Math.round((completedCount / resourceCount) * 100) : 0;
    });
  }, [completionStatus, tab, category, topics, content]);

  // Handle checkbox change
  const handleCheckboxChange = (topicTitle, resourceType) => {
    setCompletionStatus((prev) => ({
      ...prev,
      [`${topicTitle}_${resourceType}`]: !prev[`${topicTitle}_${resourceType}`],
    }));
  };

  return (
    <div className="p-6 w-full">
      <div className="mb-8">
        <Link
          href="/aptitude/learning"
          className="text-blue-600 hover:text-blue-800 text-sm font-medium mb-4 inline-block"
        >
          ← Back to Learning
        </Link>
        <h1 className="text-2xl font-bold text-gray-800">
          {category.charAt(0).toUpperCase() + category.slice(1)} - {tabName}
        </h1>
        <p className="text-gray-600 mt-2">
          Master concepts and explore resources for {category}.
        </p>
      </div>

      {topics.length > 0 ? (
        topics.map((topic, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 border border-gray-200 mb-6"
          >
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              {topic.title} ({topic.progress}%)
            </h2>

            {/* Concept */}
            <div className="mb-6">
              <h3 className="text-lg font-medium text-gray-700 mb-2">Concept</h3>
              <p className="text-gray-600">
                {content[topic.title]?.concept ||
                  "Learning content for this topic is under development."}
              </p>
            </div>

            {/* Resource Buttons with Checkboxes */}
            <div className="space-y-4">
              {content[topic.title]?.youtubeLink ? (
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={completionStatus[`${topic.title}_youtube`] || false}
                    onChange={() => handleCheckboxChange(topic.title, "youtube")}
                    className="h-5 w-5 text-blue-600 rounded"
                  />
                  <a
                    href={content[topic.title].youtubeLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700"
                  >
                    Watch Video
                  </a>
                </div>
              ) : (
                <p className="text-gray-600 text-sm">
                  No video available for this topic.
                </p>
              )}
              {content[topic.title]?.pdfLink ? (
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={completionStatus[`${topic.title}_pdf`] || false}
                    onChange={() => handleCheckboxChange(topic.title, "pdf")}
                    className="h-5 w-5 text-blue-600 rounded"
                  />
                  <a
                    href={content[topic.title].pdfLink}
                    download
                    className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700"
                  >
                    Download Concept
                  </a>
                </div>
              ) : (
                <p className="text-gray-600 text-sm">
                  No PDF available for this topic.
                </p>
              )}
            </div>
          </div>
        ))
      ) : (
        <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <p className="text-gray-600">
            No topics found for {category} in {tabName}.
          </p>
        </div>
      )}
    </div>
  );
};

export default CategoryLearning;