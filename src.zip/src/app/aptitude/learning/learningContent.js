export const learningContent = {
    quantitative: {
      arithmetic: {
        "Number System": {
          concept: "The number system forms the basis of mathematics, including natural numbers (1, 2, 3, ...), whole numbers (0, 1, 2, ...), integers (..., -2, -1, 0, 1, 2, ...), rational numbers (p/q where q ≠ 0), and irrational numbers (e.g., √2, π). Understanding their properties is key to solving numerical problems.",
          youtubeLink: "https://www.youtube.com/watch?v=bJCdFBfSR5Q&pp=ygUkTnVtYmVyIFN5c3RlbSAgYXB0aXR1ZGUgIGluIG9uZSBzaG90",
          pdfLink: "public\pdfs\Number-System.pdf",
        },
        "Divisibility Rules": {
          concept: "Divisibility rules allow quick checks for divisibility without long division. For example, a number is divisible by 2 if it’s even, by 3 if the sum of digits is divisible by 3, by 4 if the last two digits form a number divisible by 4, etc.",
          youtubeLink: "https://www.youtube.com/live/2L7O68uwI3E?si=nm0owHLTaXU9Ct0Y",
          pdfLink: "https://example.com/pdfs/quantitative/arithmetic/divisibility-rules.pdf",
        },
        "Prime and Composite Numbers": {
          concept: "Prime numbers have only two factors (1 and themselves), e.g., 2, 3, 5. Composite numbers have more than two factors, e.g., 4, 6, 8. 1 is neither prime nor composite.",
          youtubeLink: "",
          pdfLink: "",
        },
        "HCF and LCM": {
          concept: "Highest Common Factor (HCF) is the largest number dividing two or more numbers. Least Common Multiple (LCM) is the smallest number divisible by them. Used in problems like time cycles or fraction simplification.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Properties of Numbers": {
          concept: "Numbers have properties like even/odd, positive/negative, or being perfect squares/cubes. These properties help simplify calculations and solve problems efficiently.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Remainders": {
          concept: "Remainder is the amount left after division when one number doesn’t divide another exactly. Remainder theorems (e.g., Fermat’s, Wilson’s) help in modular arithmetic.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Unit Digit Calculation": {
          concept: "Unit digit of a number is its last digit. Useful for finding unit digits of large powers or products without full computation.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Percentages": {
          concept: "Percentage represents a fraction out of 100. Used in profit, loss, interest, and data interpretation problems.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Ratio and Proportion": {
          concept: "Ratio compares two quantities (a:b). Proportion states two ratios are equal (a/b = c/d). Used in mixing problems, scaling, and partnerships.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Averages": {
          concept: "Average is the sum of quantities divided by their count. Used to find central tendencies or balance points.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Profit and Loss": {
          concept: "Profit occurs when selling price (SP) exceeds cost price (CP); loss when CP > SP. Profit% = [(SP - CP)/CP] × 100.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Simple and Compound Interest": {
          concept: "Simple Interest (SI) = (P × R × T)/100. Compound Interest (CI) involves interest on interest, calculated as CI = P(1 + R/100)^T - P.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Time and Work": {
          concept: "Time and work problems involve calculating work done based on rates. If A does a job in x days, rate = 1/x per day.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Time, Speed, and Distance": {
          concept: "Speed = Distance / Time. Used in problems involving relative speeds, trains, boats, etc.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Mixtures and Alligations": {
          concept: "Alligation finds the ratio in which two ingredients at different prices/qualities are mixed to get a desired average.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Progressions": {
          concept: "Arithmetic Progression (AP): constant difference, e.g., 2, 5, 8. Geometric Progression (GP): constant ratio, e.g., 2, 4, 8.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Logarithms": {
          concept: "Logarithms are inverses of exponents: if a^x = b, then log_a(b) = x. Used in growth, decay, and complex calculations.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      algebra: {
        "Basic Algebraic Expressions": {
          concept: "Algebraic expressions combine numbers and variables using operations. Simplifying them involves combining like terms and factoring.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Linear Equations": {
          concept: "Linear equations have variables with degree 1, e.g., ax + b = 0. Solving involves isolating the variable.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Quadratic Equations": {
          concept: "Quadratic equations are of form ax^2 + bx + c = 0. Solved using factoring, quadratic formula, or completing the square.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Inequalities": {
          concept: "Inequalities compare expressions (e.g., x + 2 > 5). Solving involves isolating variables, noting sign changes when multiplying/dividing by negatives.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Functions": {
          concept: "Functions map inputs to outputs, e.g., f(x) = x^2. Key concepts include domain, range, and types (linear, quadratic).",
          youtubeLink: "",
          pdfLink: "",
        },
        "Set Theory": {
          concept: "Set theory deals with collections of objects. Operations include union, intersection, and complement.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Indices and Surds": {
          concept: "Indices represent powers (a^m × a^n = a^(m+n)). Surds are irrational roots (e.g., √2).",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      geometry: {
        "Basic Geometric Shapes": {
          concept: "Basic shapes include triangles, circles, squares, etc., with properties like angles, sides, and symmetry.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Area, Perimeter, Volume": {
          concept: "Area measures surface, perimeter measures boundary, volume measures space. Formulas vary by shape.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Coordinate Geometry": {
          concept: "Coordinate geometry uses x-y coordinates to define points, lines, and shapes. Includes distance, midpoint, slope.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      combinatorics: {
        "Permutation and Combination": {
          concept: "Permutations (order matters): nPr = n!/(n-r)!. Combinations (order doesn’t): nCr = n!/[r!(n-r)!].",
          youtubeLink: "",
          pdfLink: "",
        },
        "Probability": {
          concept: "Probability = (Favorable outcomes) / (Total outcomes). Ranges from 0 to 1.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
    },
    logical: {
      deductive: {
        "Syllogisms": {
          concept: "Syllogisms involve two premises leading to a conclusion, e.g., All A are B; All B are C → All A are C.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Logical Deductions": {
          concept: "Logical deductions derive conclusions from given statements using rules of inference.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Statement and Conclusions": {
          concept: "Determine if conclusions follow from given statements logically.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Statement and Arguments": {
          concept: "Evaluate if arguments support or weaken a statement.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Statement and Assumptions": {
          concept: "Identify unstated assumptions necessary for a statement to hold.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Course of Action": {
          concept: "Choose actions that logically address a given problem.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      inductive: {
        "Series Completion": {
          concept: "Identify patterns in number or letter sequences to find the next term.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Analogies": {
          concept: "Analogies test relationships: A is to B as C is to D.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Classification": {
          concept: "Group items based on common properties, identifying the odd one out.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Pattern Recognition": {
          concept: "Identify repeating or evolving patterns in sequences or shapes.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      arrangements: {
        "Linear Arrangements": {
          concept: "Arrange objects in a straight line based on conditions (e.g., rank, position).",
          youtubeLink: "",
          pdfLink: "",
        },
        "Circular Arrangements": {
          concept: "Arrange objects in a circle, where rotations are equivalent.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Complex Arrangements": {
          concept: "Involve multiple constraints (e.g., groups, conditions).",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      others: {
        "Blood Relations": {
          concept: "Determine family relationships based on given connections.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Coding-Decoding": {
          concept: "Decode patterns where letters/numbers are substituted or shifted.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Direction Sense": {
          concept: "Track movement based on directions (N, S, E, W) and distances.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Data Sufficiency": {
          concept: "Determine if given data is enough to answer a question.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Puzzles": {
          concept: "Solve problems with multiple constraints, often involving logic.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Calendar and Clocks": {
          concept: "Solve problems involving dates, days, or time intervals.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Critical Reasoning": {
          concept: "Evaluate arguments, identifying assumptions or conclusions.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
    },
    verbal: {
      vocabulary: {
        "Synonyms and Antonyms": {
          concept: "Synonyms are words with similar meanings; antonyms are opposites. Essential for vocabulary building.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Analogies": {
          concept: "Analogies test word relationships (e.g., big : small :: fast : slow).",
          youtubeLink: "",
          pdfLink: "",
        },
        "Fill in the Blanks": {
          concept: "Choose words that fit contextually and grammatically in sentences.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Idioms and Phrases": {
          concept: "Idioms are expressions with figurative meanings, e.g., ‘kick the bucket’ = die.",
          youtubeLink: "",
          pdfLink: "",
        },
        "One Word Substitution": {
          concept: "Replace a phrase with a single word, e.g., ‘fear of heights’ = acrophobia.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      grammar: {
        "Sentence Correction": {
          concept: "Correct errors in grammar, punctuation, or style to make sentences clear.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Error Spotting": {
          concept: "Identify specific grammatical errors in sentences.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Tenses": {
          concept: "Tenses indicate time of action (past, present, future). Correct tense ensures clarity.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Articles and Prepositions": {
          concept: "Articles (a, an, the) specify nouns; prepositions show relationships (in, on, at).",
          youtubeLink: "",
          pdfLink: "",
        },
        "Subject-Verb Agreement": {
          concept: "Subject and verb must agree in number (singular/plural).",
          youtubeLink: "",
          pdfLink: "",
        },
        "Parts of Speech": {
          concept: "Words are classified as nouns, verbs, adjectives, etc., each with specific roles.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      comprehension: {
        "Reading Comprehension": {
          concept: "Understand and interpret passages, answering questions on main idea, details, or inferences.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Sentence Rearrangement": {
          concept: "Rearrange jumbled sentences to form a coherent paragraph.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Verbal Analogies": {
          concept: "Similar to vocabulary analogies, test word relationships in context.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Cloze Test": {
          concept: "Fill multiple blanks in a passage to maintain coherence.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
    },
    data_interpretation: {
      data: {
        "Tables": {
          concept: "Tables organize data in rows and columns for analysis, often requiring calculations.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Bar Graphs": {
          concept: "Bar graphs represent data with bars, comparing quantities across categories.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Pie Charts": {
          concept: "Pie charts show proportions as slices of a circle, often in percentages.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Line Graphs": {
          concept: "Line graphs show trends over time or continuous data.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Caselets": {
          concept: "Caselets provide data in paragraph form, requiring extraction and calculation.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
      logical: {
        "Data Sufficiency": {
          concept: "Same as logical data sufficiency, applied to data-based questions.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Puzzles": {
          concept: "Data-driven puzzles require logical arrangement of information.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Critical Reasoning": {
          concept: "Evaluate arguments based on data, similar to logical reasoning.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
    },
    abstract: {
      figural: {
        "Series Completion": {
          concept: "Identify patterns in shapes or figures to predict the next.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Analogies": {
          concept: "Figure analogies test visual relationships, e.g., shape A to B as C to D.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Classification": {
          concept: "Group figures by properties, finding the odd one out.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Mirror Images": {
          concept: "Mirror images flip figures horizontally or vertically.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Water Images": {
          concept: "Water images flip figures vertically, as seen in water reflection.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Paper Folding": {
          concept: "Determine how a folded and cut paper looks when unfolded.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
    },
    situational: {
      judgement: {
        "Workplace Scenarios": {
          concept: "Evaluate responses to workplace situations, testing ethics and professionalism.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Decision Making": {
          concept: "Choose actions based on scenarios, balancing risks and benefits.",
          youtubeLink: "",
          pdfLink: "",
        },
        "Evaluating Responses": {
          concept: "Judge the appropriateness of responses to scenarios.",
          youtubeLink: "",
          pdfLink: "",
        },
      },
    },
  };